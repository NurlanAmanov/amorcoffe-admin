// import axios from "axios";

// const BASE_URL = "https://finalprojectt-001-site1.jtempurl.com/api/Product";

// // 🔹 Məhsul əlavə etmə funksiyası
// export const addProduct = async (productData) => {
//     try {
//         const response = await axios.post(BASE_URL, productData, {
//             headers: { "Content-Type": "application/json" },
//         });
//         return response.data;
//     } catch (error) {
//         throw error.response?.data || error.message;
//     }
// };
