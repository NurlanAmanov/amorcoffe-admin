import React from 'react'

function Adminfooter() {
  return (
    <div>Adminfooter</div>
  )
}

export default Adminfooter